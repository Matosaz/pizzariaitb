
const Inicio = () => {

    return(
        <h2>Nova página de Início</h2>
    )
}

export default Inicio